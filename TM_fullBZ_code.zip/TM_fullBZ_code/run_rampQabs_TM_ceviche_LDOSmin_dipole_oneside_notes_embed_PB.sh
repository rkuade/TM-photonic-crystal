#!/bin/bash
#SBATCH --job-name=TMLDOSmin_Qabs1e1_des1by1_chi7d9_emit1_maxeval20000_gpr10_tenpoles_rand1
#SBATCH --output=TM_LDOSmin_dipole_Qabs1e1_des1by1_chi7d9_emit1_maxeval20000_gpr10_tenpoles_randstart1.txt
#SBATCH -N 1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=64
#SBATCH --time=20-00:00:00
#SBATCH --mem-per-cpu=10000
#SBATCH --error=TM_errorminQabs1e1_des1by1_chi7d9_emit10_maxeval20000_gpr10_tenpoles_rand1.err
 
module load anaconda3/2023.9
conda activate PB_env

# defines the program name to be run
prog=rampQabs_TM_ceviche_LDOSmin_dipole_oneside_notes_embed_PB.py

# input parameters for the calculation
wavelength=1.0
pow10Qabs_start=1.0
pow10Qabs_end=1.0
pow10Qabs_num=1
Num_Poles=10
geometry='Cavity'

ReChi=7.9
ImChi=0.0

# number of gridpoints per length equal to 1
gpr=10

# size of design region (in x and y)
design_x=1.0
design_y=1.0

# size of cavity/vacuum region in the design region
vacuum_x=0.0
vacuum_y=0.0
dist_x=0.0

# size of region of dipoles (in x and y)
emitter_x=1.0
emitter_y=1.0

# more simulation parameters (for convergence)
pml_thick=0.0
pml_sep=0.0

# initialization of design region with material
init_type='alt'
init_file='run_Qabs1e1_maxeval20000_des1by1_chi7d9_tenpoles_TM_rand1.txt'

# number of iterations after which to output the current design
output_base=50

# maximum number of iterations
maxeval=20000

# name of ouput file
name='TMmin_dipole_Qabs1e1_emit1_maxeval20000_gpr10_oneside_des1by1_cav0d0_chi7d9_tenpoles_rand1'


# run the program
python3 $prog -wavelength $wavelength -pow10Qabs_start $pow10Qabs_start -pow10Qabs_end $pow10Qabs_end -pow10Qabs_num $pow10Qabs_num -ReChi $ReChi -ImChi $ImChi -gpr $gpr -design_x $design_x -design_y $design_y -vacuum_x $vacuum_x -vacuum_y $vacuum_y -emitter_x $emitter_x -emitter_y $emitter_y -pml_thick $pml_thick -pml_sep $pml_sep -init_type $init_type -init_file $init_file -output_base $output_base -name $name -maxeval $maxeval -dist_x $dist_x -Num_Poles $Num_Poles -geometry $geometry >> TM_LDOSmin_dipole_Qabs1e1_oneside_chi7d9_des1by1_emit1_maxeval20000_gpr10_tenpoles_rand1.txt

