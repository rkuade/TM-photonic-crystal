import numpy as np
import autograd.numpy as npa
#from autograd import jacobian
import matplotlib.pyplot as plt
#from scipy.optimize import approx_fprime as jacobian
import ceviche
from ceviche import jacobian
from ceviche.constants import ETA_0, C_0, MU_0, EPSILON_0
import Yee_TM_FDFD_ceviche
import random
import sys

# calculate and return the local density of states (ldos) for each complex 
# frequency at which the ldos is being evaluated
def source_ldos(source, Ezs, dl, Num_Poles, ii):
    ldos = 0
    Polefactor = 0
    for nn in range(Num_Poles):
        Polefactor += -1j*np.exp(1j*(np.pi+nn*2.*np.pi)/(2.*Num_Poles))
    ldos += dl**2 * 0.5 * npa.real(-1j*(np.exp(1j*(np.pi+2.*ii*np.pi)/(2.*Num_Poles))/Polefactor*npa.sum(npa.conj(source) * (Ezs))))
    return ldos

# rescale a vector of continuous variables representing the degrees of freedom 
# in the grid, and that all lie between 0 and 1, to permittivity values 
def scale_dof_to_eps(dof, epsmin, epsmax):
    return epsmin + dof * (epsmax-epsmin)

# construct the material (fill in the appropriate permittivity at each pixel 
# in the grid)
def eps_parametrization(dof, epsmin, epsmax, designMask, epsBkg):

    eps = scale_dof_to_eps(dof, epsmin, epsmax) * designMask + epsBkg * (1-designMask)
    return eps


# construct material and calculate ldos
def ldos_objective(dof, epsval, designMask, dl, source, sims, kx, ky, Mx, My, Num_Poles):
    Nx,Ny = source.shape
    dof = dof.reshape((Nx,Ny))
        
    epsBkg = np.ones((Nx,Ny), dtype=complex)
    eps = eps_parametrization(dof, 1.0, epsval, designMask, epsBkg)
    Ezs = []
    ldos = 0
    xl = np.linspace(0,Mx-1,Mx)/Mx
    yl = np.linspace(0,My-1,My)/My
    xg, yg = np.meshgrid(xl,yl)
    for ii in range(len(sims)):
        sims[ii].eps_r = eps
        _,_,Ez1 = sims[ii].solve(source*np.exp(1j*(kx[ii]*xg+ky[ii]*yg)))
        ldos += source_ldos(source*np.exp(1j*(kx[ii]*xg+ky[ii]*yg)), Ez1, dl, Num_Poles, ii//(Mx*My))
    return ldos


def designdof_ldos_objective(designdof, designgrad, epsval, designMask, dl, source, omega, Num_Poles, Qabs, epsVac, Npml, opt_data, Mx, My):
    """
    optimization objective to be used with NLOPT
    opt_data is dictionary with auxiliary info such as current iteration number and output base
    """
    
    omegas = []
    
    xl = np.linspace(0,Mx-1,Mx)
    yl = np.linspace(0,My-1,My)
    xg, yg = np.meshgrid(xl,yl)
    sims = []
    kx = []
    ky = []
    ind = 0
    for nn in range(Num_Poles):
        omegas += [omega * (1-np.exp(1j*(np.pi+nn*2.*np.pi)/(2.*Num_Poles))/2./Qabs)]
        for nx in range(-int(np.ceil(Mx/2))+1,int(np.floor(Mx/2))+1):
            for ny in range(-int(np.ceil(My/2))+1,int(np.floor(My/2))+1):
                kx += [2*np.pi*nx/Mx]
                ky += [2*np.pi*ny/My] 
                sims += [Yee_TM_FDFD_ceviche.fdfd_TM(omegas[nn], dl, kx[ind], ky[ind], epsVac, [Npml,Npml])]
                ind += 1
    Nx,Ny = source.shape
    dof = np.zeros((Nx,Ny))
    dof[designMask] = designdof[:]
    objfunc = lambda d: ldos_objective(d, epsval, designMask, dl, source, sims, kx, ky, Mx, My, Num_Poles)
    obj = objfunc(dof.flatten())
    opt_data['count'] += 1
    print('at iteration #', opt_data['count'], 'the ldos value is', obj, ' with enhancement', obj/opt_data['vac_ldos'], flush=True)
    if opt_data['count'] % opt_data['output_base'] == 0:
        np.savetxt(opt_data['name']+'_dof'+str(opt_data['count'])+'.txt', designdof[:])

    if len(designgrad)>0:
        jac_objfunc = jacobian(objfunc, mode='reverse')
        fullgrad = jac_objfunc(dof.flatten())
        designgrad[:] = np.reshape(fullgrad, (Nx,Ny))[designMask]

    return obj

