# used for setup.py
name = "Yee_TM_FDFD_ceviche"

from .Yee_TM_FDFD_ceviche import fdfd_TM


__version__ = '0.1.3'
